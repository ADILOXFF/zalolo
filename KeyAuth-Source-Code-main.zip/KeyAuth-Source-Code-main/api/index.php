<?php
header("Location: https://keyauth.readme.io/");
exit();
